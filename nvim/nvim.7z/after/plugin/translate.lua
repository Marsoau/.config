function ToUkr()
	vim.cmd("%s/ы/і/g")
	vim.cmd("%s/э/є/g")
	vim.cmd("%s/ъ/ї/g")
	--vim.cmd("%s/Ы/І/g")
	--vim.cmd("%s/Э/Є/g")
	--vim.cmd("%s/Ъ/Ї/g")
end
